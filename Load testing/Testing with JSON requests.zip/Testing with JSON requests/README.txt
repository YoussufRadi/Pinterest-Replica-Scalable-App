How to test?

In the folder you will find signup.yml this is an artillery script make sure you have artillery
already installed on the testing device (for installation please run npm install -g artillery)
 The script contains comments on the commands

 for more info please see the website https://gitlab.com/RainbowZephyr/Scalable-Course/blob/Manual/Tutorial%208/manual.md

 To run VisualVM please install it on the device first then add the following "-Xverify:none" without quotes in the IDE's JVM arguments
 This is exactly what OSH told me to test.